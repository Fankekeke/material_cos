import { IconDefinition } from '../types';
declare const FolderAddFill: IconDefinition;
export default FolderAddFill;
