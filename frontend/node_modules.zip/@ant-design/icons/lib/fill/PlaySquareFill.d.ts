import { IconDefinition } from '../types';
declare const PlaySquareFill: IconDefinition;
export default PlaySquareFill;
