import { IconDefinition } from '../types';
declare const FilterFill: IconDefinition;
export default FilterFill;
