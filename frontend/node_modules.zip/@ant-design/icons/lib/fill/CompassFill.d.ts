import { IconDefinition } from '../types';
declare const CompassFill: IconDefinition;
export default CompassFill;
