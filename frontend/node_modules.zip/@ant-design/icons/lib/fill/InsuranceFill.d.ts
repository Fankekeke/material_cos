import { IconDefinition } from '../types';
declare const InsuranceFill: IconDefinition;
export default InsuranceFill;
