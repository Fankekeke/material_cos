import { IconDefinition } from '../types';
declare const YuqueFill: IconDefinition;
export default YuqueFill;
