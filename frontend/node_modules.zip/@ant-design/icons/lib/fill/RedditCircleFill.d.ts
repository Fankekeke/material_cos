import { IconDefinition } from '../types';
declare const RedditCircleFill: IconDefinition;
export default RedditCircleFill;
