import { IconDefinition } from '../types';
declare const GooglePlusSquareFill: IconDefinition;
export default GooglePlusSquareFill;
