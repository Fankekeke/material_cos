import { IconDefinition } from '../types';
declare const TwitterSquareFill: IconDefinition;
export default TwitterSquareFill;
