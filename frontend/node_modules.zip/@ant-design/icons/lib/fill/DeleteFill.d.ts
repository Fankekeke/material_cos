import { IconDefinition } from '../types';
declare const DeleteFill: IconDefinition;
export default DeleteFill;
