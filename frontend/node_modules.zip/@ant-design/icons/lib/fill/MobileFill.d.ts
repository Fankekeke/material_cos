import { IconDefinition } from '../types';
declare const MobileFill: IconDefinition;
export default MobileFill;
