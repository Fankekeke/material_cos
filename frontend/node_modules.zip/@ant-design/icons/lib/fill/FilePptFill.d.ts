import { IconDefinition } from '../types';
declare const FilePptFill: IconDefinition;
export default FilePptFill;
