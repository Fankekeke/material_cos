import { IconDefinition } from '../types';
declare const ScheduleFill: IconDefinition;
export default ScheduleFill;
