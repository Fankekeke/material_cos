import { IconDefinition } from '../types';
declare const DollarCircleFill: IconDefinition;
export default DollarCircleFill;
