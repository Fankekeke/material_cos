import { IconDefinition } from '../types';
declare const IeSquareFill: IconDefinition;
export default IeSquareFill;
