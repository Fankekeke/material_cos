import { IconDefinition } from '../types';
declare const ZhihuSquareFill: IconDefinition;
export default ZhihuSquareFill;
