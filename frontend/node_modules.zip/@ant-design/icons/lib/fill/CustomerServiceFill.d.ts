import { IconDefinition } from '../types';
declare const CustomerServiceFill: IconDefinition;
export default CustomerServiceFill;
