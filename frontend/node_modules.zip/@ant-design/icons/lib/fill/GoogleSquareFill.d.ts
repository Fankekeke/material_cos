import { IconDefinition } from '../types';
declare const GoogleSquareFill: IconDefinition;
export default GoogleSquareFill;
