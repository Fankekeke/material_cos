import { IconDefinition } from '../types';
declare const TaobaoCircleFill: IconDefinition;
export default TaobaoCircleFill;
