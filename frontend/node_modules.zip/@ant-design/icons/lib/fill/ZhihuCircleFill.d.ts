import { IconDefinition } from '../types';
declare const ZhihuCircleFill: IconDefinition;
export default ZhihuCircleFill;
