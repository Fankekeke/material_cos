import { IconDefinition } from '../types';
declare const ProjectFill: IconDefinition;
export default ProjectFill;
