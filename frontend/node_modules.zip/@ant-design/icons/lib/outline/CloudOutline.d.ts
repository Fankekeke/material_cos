import { IconDefinition } from '../types';
declare const CloudOutline: IconDefinition;
export default CloudOutline;
