import { IconDefinition } from '../types';
declare const CalendarOutline: IconDefinition;
export default CalendarOutline;
