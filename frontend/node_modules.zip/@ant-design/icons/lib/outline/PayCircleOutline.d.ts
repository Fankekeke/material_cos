import { IconDefinition } from '../types';
declare const PayCircleOutline: IconDefinition;
export default PayCircleOutline;
