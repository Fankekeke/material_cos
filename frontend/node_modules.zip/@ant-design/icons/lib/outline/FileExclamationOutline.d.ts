import { IconDefinition } from '../types';
declare const FileExclamationOutline: IconDefinition;
export default FileExclamationOutline;
