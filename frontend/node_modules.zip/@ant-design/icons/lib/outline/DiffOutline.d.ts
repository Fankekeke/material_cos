import { IconDefinition } from '../types';
declare const DiffOutline: IconDefinition;
export default DiffOutline;
