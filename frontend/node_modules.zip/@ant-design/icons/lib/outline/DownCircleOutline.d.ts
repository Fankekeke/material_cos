import { IconDefinition } from '../types';
declare const DownCircleOutline: IconDefinition;
export default DownCircleOutline;
