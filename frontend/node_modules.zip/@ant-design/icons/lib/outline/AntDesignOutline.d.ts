import { IconDefinition } from '../types';
declare const AntDesignOutline: IconDefinition;
export default AntDesignOutline;
