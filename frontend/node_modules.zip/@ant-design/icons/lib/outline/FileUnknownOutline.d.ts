import { IconDefinition } from '../types';
declare const FileUnknownOutline: IconDefinition;
export default FileUnknownOutline;
