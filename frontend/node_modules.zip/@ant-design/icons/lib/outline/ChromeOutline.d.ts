import { IconDefinition } from '../types';
declare const ChromeOutline: IconDefinition;
export default ChromeOutline;
