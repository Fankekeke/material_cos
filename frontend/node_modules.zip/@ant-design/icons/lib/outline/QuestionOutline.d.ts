import { IconDefinition } from '../types';
declare const QuestionOutline: IconDefinition;
export default QuestionOutline;
