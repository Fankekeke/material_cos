import { IconDefinition } from '../types';
declare const HeartOutline: IconDefinition;
export default HeartOutline;
