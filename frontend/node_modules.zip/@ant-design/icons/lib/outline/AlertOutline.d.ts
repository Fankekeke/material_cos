import { IconDefinition } from '../types';
declare const AlertOutline: IconDefinition;
export default AlertOutline;
