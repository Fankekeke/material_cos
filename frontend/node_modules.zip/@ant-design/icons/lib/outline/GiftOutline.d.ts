import { IconDefinition } from '../types';
declare const GiftOutline: IconDefinition;
export default GiftOutline;
