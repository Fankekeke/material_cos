import { IconDefinition } from '../types';
declare const ReconciliationOutline: IconDefinition;
export default ReconciliationOutline;
