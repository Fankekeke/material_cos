import { IconDefinition } from '../types';
declare const IssuesCloseOutline: IconDefinition;
export default IssuesCloseOutline;
