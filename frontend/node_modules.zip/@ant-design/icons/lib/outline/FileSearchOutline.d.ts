import { IconDefinition } from '../types';
declare const FileSearchOutline: IconDefinition;
export default FileSearchOutline;
