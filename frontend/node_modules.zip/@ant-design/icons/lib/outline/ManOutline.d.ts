import { IconDefinition } from '../types';
declare const ManOutline: IconDefinition;
export default ManOutline;
