import { IconDefinition } from '../types';
declare const MediumOutline: IconDefinition;
export default MediumOutline;
