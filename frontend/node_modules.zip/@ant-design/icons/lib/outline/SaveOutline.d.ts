import { IconDefinition } from '../types';
declare const SaveOutline: IconDefinition;
export default SaveOutline;
