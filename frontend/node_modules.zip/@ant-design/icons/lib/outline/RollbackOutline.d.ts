import { IconDefinition } from '../types';
declare const RollbackOutline: IconDefinition;
export default RollbackOutline;
