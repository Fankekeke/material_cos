import { IconDefinition } from '../types';
declare const SafetyCertificateOutline: IconDefinition;
export default SafetyCertificateOutline;
