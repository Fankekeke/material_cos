import { IconDefinition } from '../types';
declare const PlayCircleOutline: IconDefinition;
export default PlayCircleOutline;
