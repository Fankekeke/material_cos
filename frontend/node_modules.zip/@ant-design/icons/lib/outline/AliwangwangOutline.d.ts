import { IconDefinition } from '../types';
declare const AliwangwangOutline: IconDefinition;
export default AliwangwangOutline;
