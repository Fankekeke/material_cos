import { IconDefinition } from '../types';
declare const ScissorOutline: IconDefinition;
export default ScissorOutline;
