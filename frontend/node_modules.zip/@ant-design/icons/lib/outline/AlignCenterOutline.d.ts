import { IconDefinition } from '../types';
declare const AlignCenterOutline: IconDefinition;
export default AlignCenterOutline;
