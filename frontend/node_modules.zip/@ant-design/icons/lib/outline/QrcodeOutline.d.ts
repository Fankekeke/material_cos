import { IconDefinition } from '../types';
declare const QrcodeOutline: IconDefinition;
export default QrcodeOutline;
