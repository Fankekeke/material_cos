import { IconDefinition } from '../types';
declare const GoldOutline: IconDefinition;
export default GoldOutline;
