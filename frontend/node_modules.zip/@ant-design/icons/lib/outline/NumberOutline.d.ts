import { IconDefinition } from '../types';
declare const NumberOutline: IconDefinition;
export default NumberOutline;
