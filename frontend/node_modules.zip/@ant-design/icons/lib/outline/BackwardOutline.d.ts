import { IconDefinition } from '../types';
declare const BackwardOutline: IconDefinition;
export default BackwardOutline;
