import { IconDefinition } from '../types';
declare const KeyOutline: IconDefinition;
export default KeyOutline;
