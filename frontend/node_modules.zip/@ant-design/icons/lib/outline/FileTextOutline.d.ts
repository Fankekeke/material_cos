import { IconDefinition } from '../types';
declare const FileTextOutline: IconDefinition;
export default FileTextOutline;
