import { IconDefinition } from '../types';
declare const FilterOutline: IconDefinition;
export default FilterOutline;
