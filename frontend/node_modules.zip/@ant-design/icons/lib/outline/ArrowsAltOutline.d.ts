import { IconDefinition } from '../types';
declare const ArrowsAltOutline: IconDefinition;
export default ArrowsAltOutline;
