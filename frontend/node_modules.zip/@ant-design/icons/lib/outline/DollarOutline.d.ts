import { IconDefinition } from '../types';
declare const DollarOutline: IconDefinition;
export default DollarOutline;
