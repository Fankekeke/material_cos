import { IconDefinition } from '../types';
declare const FileMarkdownOutline: IconDefinition;
export default FileMarkdownOutline;
