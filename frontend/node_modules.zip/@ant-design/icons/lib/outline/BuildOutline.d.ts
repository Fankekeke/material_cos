import { IconDefinition } from '../types';
declare const BuildOutline: IconDefinition;
export default BuildOutline;
