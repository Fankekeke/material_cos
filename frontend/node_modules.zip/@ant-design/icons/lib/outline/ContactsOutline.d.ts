import { IconDefinition } from '../types';
declare const ContactsOutline: IconDefinition;
export default ContactsOutline;
