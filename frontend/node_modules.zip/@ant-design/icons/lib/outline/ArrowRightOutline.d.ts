import { IconDefinition } from '../types';
declare const ArrowRightOutline: IconDefinition;
export default ArrowRightOutline;
