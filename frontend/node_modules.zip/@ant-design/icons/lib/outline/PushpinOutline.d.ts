import { IconDefinition } from '../types';
declare const PushpinOutline: IconDefinition;
export default PushpinOutline;
