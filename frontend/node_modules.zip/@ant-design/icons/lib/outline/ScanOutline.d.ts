import { IconDefinition } from '../types';
declare const ScanOutline: IconDefinition;
export default ScanOutline;
