import { IconDefinition } from '../types';
declare const RestOutline: IconDefinition;
export default RestOutline;
