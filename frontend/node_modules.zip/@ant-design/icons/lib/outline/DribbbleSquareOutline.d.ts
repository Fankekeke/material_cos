import { IconDefinition } from '../types';
declare const DribbbleSquareOutline: IconDefinition;
export default DribbbleSquareOutline;
