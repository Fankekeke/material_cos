import { IconDefinition } from '../types';
declare const BorderTopOutline: IconDefinition;
export default BorderTopOutline;
