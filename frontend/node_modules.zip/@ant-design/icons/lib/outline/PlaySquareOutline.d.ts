import { IconDefinition } from '../types';
declare const PlaySquareOutline: IconDefinition;
export default PlaySquareOutline;
